import axios from 'axios';

// Test public routes (backend API endpoints)
const api = axios.create({
  baseURL: 'http://localhost:3000/api',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

async function testPublicRoutes() {
  console.log('🌐 TESTING PUBLIC ROUTES');
  console.log('='.repeat(40));
  
  try {
    // Test customer routes (public)
    console.log('\n1. 🎫 Testing Customer Ticket Routes...');
    
    // Test ticket submission (simulated)
    const ticketData = {
      customerName: 'Test Customer',
      mobileNumber: '1234567890',
      email: 'test@example.com',
      serviceType: 'CCTV',
      problemDescription: 'Test problem description',
      address: 'Test address'
    };
    
    try {
      const response = await api.post('/customer/tickets', ticketData);
      console.log('✅ Ticket Submission: POST /customer/tickets - Status:', response.status);
      console.log('   Ticket Number:', response.data.data?.ticketNumber);
    } catch (error) {
      console.log('❌ Ticket Submission failed:', error.response?.status || error.message);
    }
    
    // Test ticket status check
    try {
      const statusResponse = await api.post('/customer/tickets/status', {
        ticketNumber: 'TKT-20260330-7648',
        contact: 'ravi@gmail.com'
      });
      console.log('✅ Ticket Status: POST /customer/tickets/status - Status:', statusResponse.status);
    } catch (error) {
      console.log('❌ Ticket Status failed:', error.response?.status || error.message);
    }
    
    // Test contact form
    try {
      const contactData = {
        name: 'Test Contact',
        email: 'contact@example.com',
        subject: 'Test Subject',
        message: 'Test message'
      };
      const contactResponse = await api.post('/customer/contact', contactData);
      console.log('✅ Contact Form: POST /customer/contact - Status:', contactResponse.status);
    } catch (error) {
      console.log('❌ Contact Form failed:', error.response?.status || error.message);
    }
    
    // Test banner routes
    console.log('\n2. 🖼️  Testing Banner Routes...');
    
    try {
      const bannersResponse = await api.get('/banners');
      console.log('✅ Get Banners: GET /banners - Status:', bannersResponse.status);
      console.log('   Banners count:', bannersResponse.data.data?.length || 0);
    } catch (error) {
      console.log('❌ Get Banners failed:', error.response?.status || error.message);
    }
    
    try {
      const activeBannersResponse = await api.get('/banners/active');
      console.log('✅ Get Active Banners: GET /banners/active - Status:', activeBannersResponse.status);
      console.log('   Active banners count:', activeBannersResponse.data.data?.length || 0);
    } catch (error) {
      console.log('❌ Get Active Banners failed:', error.response?.status || error.message);
    }
    
    console.log('\n3. 📋 Frontend Public Pages Analysis...');
    
    const publicPages = [
      { path: '/', component: 'HomePage', desc: 'Home - Landing page' },
      { path: '/about', component: 'AboutPage', desc: 'About - Company information' },
      { path: '/services', component: 'ServicesPage', desc: 'Services - Service offerings' },
      { path: '/ticket', component: 'TicketPage', desc: 'Ticket - Create support ticket' },
      { path: '/ticket-status', component: 'TicketStatusPage', desc: 'Status - Check ticket status' },
      { path: '/contact', component: 'ContactPage', desc: 'Contact - Contact form' },
    ];
    
    publicPages.forEach(page => {
      console.log(`📄 ${page.path} -> ${page.component} (${page.desc})`);
    });
    
    console.log('\n4. 🔗 Testing Frontend Accessibility...');
    
    // Test if frontend is accessible
    try {
      const frontendResponse = await axios.get('http://localhost:5175/', {
        timeout: 5000,
        validateStatus: () => true // Don't throw on any status
      });
      console.log('✅ Frontend accessible: http://localhost:5175 - Status:', frontendResponse.status);
    } catch (error) {
      console.log('❌ Frontend not accessible:', error.message);
    }
    
    console.log('\n🎉 PUBLIC ROUTES TESTING COMPLETED!');
    
  } catch (error) {
    console.error('❌ Public routes testing failed:', error.message);
  }
}

testPublicRoutes();
