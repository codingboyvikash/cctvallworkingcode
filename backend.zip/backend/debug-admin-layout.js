import axios from 'axios';

// Mock localStorage
global.localStorage = {
  data: {},
  getItem: function(key) {
    return this.data[key] || null;
  },
  setItem: function(key, value) {
    this.data[key] = value;
  }
};

// API setup
const api = axios.create({
  baseURL: 'http://localhost:3000/api',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
});

api.interceptors.request.use((config) => {
  const adminAuth = global.localStorage.getItem('adminAuth');
  const parsed = adminAuth ? JSON.parse(adminAuth) : null;
  const token = parsed?.data?.token || parsed?.token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

async function debugAdminLayout() {
  console.log('🔍 DEBUGGING ADMIN-CONTENT-WRAPPER ISSUE');
  console.log('='.repeat(60));
  
  try {
    // Login
    console.log('\n1. 🔐 Logging in...');
    const login = await api.post('/admin/login', {
      email: 'admin@example.com',
      password: 'Admin@123'
    });
    global.localStorage.setItem('adminAuth', JSON.stringify(login.data));
    console.log('✅ Login successful');
    
    // Test different pages data
    console.log('\n2. 📄 Testing all admin pages data...');
    
    const pages = [
      { name: 'Dashboard', url: '/admin/dashboard/stats', api: 'getDashboardStats' },
      { name: 'Tickets', url: '/admin/tickets', api: 'getTickets' }
    ];
    
    for (const page of pages) {
      console.log(`\n📱 ${page.name} Page:`);
      
      try {
        let response;
        if (page.api === 'getDashboardStats') {
          response = await api.get(page.url);
          console.log('  ✅ Data:', {
            totalTickets: response.data.data.totalTickets,
            openTickets: response.data.data.openTickets,
            recentTickets: response.data.data.recentTickets?.length || 0
          });
        } else if (page.api === 'getTickets') {
          response = await api.get(page.url);
          console.log('  ✅ Data:', {
            count: response.data.data.length,
            firstTicket: response.data.data[0]?.ticketNumber || 'No tickets'
          });
        }
      } catch (error) {
        console.log('  ❌ Error:', error.response?.data?.message || error.message);
      }
    }
    
    // Check CSS issues
    console.log('\n3. 🎨 Checking potential CSS issues...');
    
    console.log('Potential CSS problems that could hide content:');
    console.log('  ❌ display: none');
    console.log('  ❌ visibility: hidden');
    console.log('  ❌ opacity: 0');
    console.log('  ❌ position: absolute with negative positioning');
    console.log('  ❌ z-index issues');
    console.log('  ❌ overflow: hidden with wrong dimensions');
    
    // Check if there might be a React rendering issue
    console.log('\n4. ⚛️  React rendering issues...');
    console.log('Possible React problems:');
    console.log('  ❌ Component not mounting');
    console.log('  ❌ State not updating');
    console.log('  ❌ Conditional rendering failing');
    console.log('  ❌ Error in component causing blank render');
    console.log('  ❌ Missing return statement');
    
    console.log('\n5. 🔍 Let me check the actual components...');
    
    console.log('Components to check:');
    console.log('  • DashboardPage.jsx - fetchData function');
    console.log('  • TicketsPage.jsx - fetchTickets function');
    console.log('  • SettingsPage.jsx - static data');
    console.log('  • AnalyticsPage.jsx - static data');
    
    console.log('\n6. 🎯 Most likely issues:');
    console.log('  1. JavaScript error in component preventing render');
    console.log('  2. CSS hiding the content');
    console.log('  3. Component not receiving props correctly');
    console.log('  4. Route not loading the component');
    
    console.log('\n🔧 SOLUTION STEPS:');
    console.log('  1. Check browser console for JavaScript errors');
    console.log('  2. Check network tab for API calls');
    console.log('  3. Inspect admin-content-wrapper element');
    console.log('  4. Check if children are being passed to AdminLayout');
    
  } catch (error) {
    console.error('❌ Debug failed:', error.message);
  }
}

debugAdminLayout();
