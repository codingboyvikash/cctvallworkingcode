import axios from 'axios';

// Mock localStorage
global.localStorage = {
  data: {},
  getItem: function(key) {
    return this.data[key] || null;
  },
  setItem: function(key, value) {
    this.data[key] = value;
  }
};

// API setup
const api = axios.create({
  baseURL: 'http://localhost:3000/api',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
});

api.interceptors.request.use((config) => {
  const adminAuth = global.localStorage.getItem('adminAuth');
  const parsed = adminAuth ? JSON.parse(adminAuth) : null;
  const token = parsed?.data?.token || parsed?.token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

async function finalVerification() {
  console.log('🔥 FINAL VERIFICATION - SAB KICH CHECK KARTE HAIN');
  console.log('='.repeat(60));
  
  let allTestsPassed = true;
  
  try {
    // Test 1: Backend Health
    console.log('\n1. 🏥 Backend Health Check...');
    try {
      const health = await api.get('/health');
      console.log('✅ Backend: RUNNING -', health.data.message);
    } catch (error) {
      console.log('❌ Backend: DOWN -', error.message);
      allTestsPassed = false;
    }
    
    // Test 2: Admin Login
    console.log('\n2. 🔐 Admin Login...');
    try {
      const login = await api.post('/admin/login', {
        email: 'admin@example.com',
        password: 'Admin@123'
      });
      global.localStorage.setItem('adminAuth', JSON.stringify(login.data));
      console.log('✅ Login: SUCCESS - Token received');
      console.log('   Admin:', login.data.data.admin.name);
    } catch (error) {
      console.log('❌ Login: FAILED -', error.response?.data?.message || error.message);
      allTestsPassed = false;
    }
    
    // Test 3: Dashboard Stats
    console.log('\n3. 📊 Dashboard Stats...');
    try {
      const stats = await api.get('/admin/dashboard/stats');
      console.log('✅ Stats: SUCCESS');
      console.log('   Total Tickets:', stats.data.data.totalTickets);
      console.log('   Open Tickets:', stats.data.data.openTickets);
      console.log('   In Progress:', stats.data.data.inProgressTickets);
      console.log('   Closed Tickets:', stats.data.data.closedTickets);
    } catch (error) {
      console.log('❌ Stats: FAILED -', error.response?.data?.message || error.message);
      allTestsPassed = false;
    }
    
    // Test 4: Get Tickets (Fixed Issue)
    console.log('\n4. 🎫 Get Tickets (Main Issue)...');
    try {
      const tickets = await api.get('/admin/tickets');
      console.log('✅ Tickets: SUCCESS');
      console.log('   Count:', tickets.data.data.length);
      console.log('   Data Type:', Array.isArray(tickets.data.data) ? 'Array ✅' : 'Not Array ❌');
      
      if (Array.isArray(tickets.data.data) && tickets.data.data.length > 0) {
        console.log('   First Ticket:', {
          number: tickets.data.data[0].ticketNumber,
          customer: tickets.data.data[0].customerName,
          service: tickets.data.data[0].serviceType,
          status: tickets.data.data[0].status
        });
      }
    } catch (error) {
      console.log('❌ Tickets: FAILED -', error.response?.data?.message || error.message);
      allTestsPassed = false;
    }
    
    // Test 5: Frontend Accessibility
    console.log('\n5. 🌐 Frontend Accessibility...');
    try {
      const frontend = await axios.get('http://localhost:5175/', {
        timeout: 5000,
        validateStatus: () => true
      });
      if (frontend.status === 200) {
        console.log('✅ Frontend: ACCESSIBLE - http://localhost:5175');
      } else {
        console.log('⚠️ Frontend: ACCESSIBLE but status:', frontend.status);
      }
    } catch (error) {
      console.log('❌ Frontend: NOT ACCESSIBLE -', error.message);
      allTestsPassed = false;
    }
    
    // Test 6: Filter Test
    console.log('\n6. 🔍 Filter Test...');
    try {
      const filtered = await api.get('/admin/tickets?status=Open');
      console.log('✅ Filter: SUCCESS');
      console.log('   Open Tickets Found:', filtered.data.data.length);
    } catch (error) {
      console.log('❌ Filter: FAILED -', error.response?.data?.message || error.message);
      allTestsPassed = false;
    }
    
    // Final Result
    console.log('\n' + '='.repeat(60));
    if (allTestsPassed) {
      console.log('🎉 ALL TESTS PASSED! SAB KUCH CHAL RAHA HAI!');
      console.log('\n📱 ACCESS LINKS:');
      console.log('   • Frontend: http://localhost:5175');
      console.log('   • Admin Login: http://localhost:5175/admin/login');
      console.log('   • Dashboard: http://localhost:5175/admin/dashboard');
      console.log('\n🔑 LOGIN DETAILS:');
      console.log('   • Email: admin@example.com');
      console.log('   • Password: Admin@123');
      console.log('\n✅ TICKETS DISPLAY: FIXED!');
      console.log('   • Ab 4 tickets show honge');
      console.log('   • Table properly render hoga');
      console.log('   • Filters kaam karenge');
    } else {
      console.log('❌ KUCH ISSUES HAI! Check karo upar wali errors');
    }
    console.log('='.repeat(60));
    
  } catch (error) {
    console.error('💥 VERIFICATION FAILED:', error.message);
  }
}

finalVerification();
