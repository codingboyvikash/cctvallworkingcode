import Banner from '../models/Banner.js';

const createBanner = async (req, res, next) => {
  try {
    const { title, description, status, position } = req.body;
    
    if (!req.file) {
      return res.status(400).json({ 
        success: false, 
        message: 'Banner image is required' 
      });
    }

    const banner = new Banner({
      title,
      description,
      image: req.file.path,
      status: status || 'active',
      position: position || 'home'
    });

    await banner.save();

    res.status(201).json({
      success: true,
      message: 'Banner created successfully',
      data: banner
    });
  } catch (error) {
    next(error);
  }
};

const getAllBanners = async (req, res, next) => {
  try {
    const { page = 1, limit = 10, status, position } = req.query;
    const query = {};
    
    if (status) query.status = status;
    if (position) query.position = position;

    const banners = await Banner.find(query)
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Banner.countDocuments(query);

    res.status(200).json({
      success: true,
      message: 'Banners retrieved successfully',
      data: banners,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
};

const getBannerById = async (req, res, next) => {
  try {
    const banner = await Banner.findById(req.params.id);
    
    if (!banner) {
      return res.status(404).json({ 
        success: false, 
        message: 'Banner not found' 
      });
    }

    res.status(200).json({
      success: true,
      message: 'Banner retrieved successfully',
      data: banner
    });
  } catch (error) {
    next(error);
  }
};

const updateBanner = async (req, res, next) => {
  try {
    const { title, description, status, position } = req.body;
    const updateData = { title, description, status, position };
    
    if (req.file) {
      updateData.image = req.file.path;
    }

    const banner = await Banner.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true, runValidators: true }
    );

    if (!banner) {
      return res.status(404).json({ 
        success: false, 
        message: 'Banner not found' 
      });
    }

    res.status(200).json({
      success: true,
      message: 'Banner updated successfully',
      data: banner
    });
  } catch (error) {
    next(error);
  }
};

const deleteBanner = async (req, res, next) => {
  try {
    const banner = await Banner.findByIdAndDelete(req.params.id);
    
    if (!banner) {
      return res.status(404).json({ 
        success: false, 
        message: 'Banner not found' 
      });
    }

    res.status(200).json({
      success: true,
      message: 'Banner deleted successfully'
    });
  } catch (error) {
    next(error);
  }
};

const getActiveBanners = async (req, res, next) => {
  try {
    const { position } = req.query;
    const query = { status: 'active' };
    
    if (position) query.position = position;

    const banners = await Banner.find(query)
      .sort({ createdAt: -1 })
      .select('title description image position');

    res.status(200).json({
      success: true,
      message: 'Active banners retrieved successfully',
      data: banners
    });
  } catch (error) {
    next(error);
  }
};

export {
  createBanner,
  getAllBanners,
  getBannerById,
  updateBanner,
  deleteBanner,
  getActiveBanners
};
