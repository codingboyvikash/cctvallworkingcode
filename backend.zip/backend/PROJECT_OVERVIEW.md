# IT CCTV Backend - Project Overview

## 📋 Project Information (PI)

**Project Name:** IT CCTV Backend API  
**Version:** 1.0.0  
**Type:** RESTful API Backend  
**Architecture:** MVC (Model-View-Controller) Pattern  
**Database:** MongoDB with Mongoose ODM  
**Framework:** Express.js  

---

## 🏗️ MVC Architecture Structure

### **Models (Data Layer)**
Location: `src/models/`

| Model | Purpose | Fields |
|-------|---------|--------|
| **Admin** | User authentication & authorization | name, email, password, role |
| **Ticket** | Service ticket management | ticketNumber, customerName, mobileNumber, email, serviceType, problemDescription, address, status, assignedTechnician, notes |
| **Banner** | Content management system | title, description, image, status, position |

### **Controllers (Business Logic)**
Location: `src/controllers/`

| Controller | Functions | Purpose |
|------------|-----------|---------|
| **adminController** | adminLogin, getDashboardStats, getTickets, getSingleTicket, updateTicket | Admin operations & ticket management |
| **customerController** | submitTicket, checkTicketStatus, submitContactInquiry | Customer-facing operations |
| **bannerController** | createBanner, getAllBanners, getBannerById, updateBanner, deleteBanner, getActiveBanners | Banner management system |

### **Routes (API Endpoints)**
Location: `src/routes/`

| Route File | Endpoints | Purpose |
|------------|-----------|---------|
| **adminRoutes** | `/api/admin/*` | Admin authentication & dashboard |
| **customerRoutes** | `/api/customer/*` | Customer ticket operations |
| **bannerRoutes** | `/api/banners/*` | Banner management |

---

## 🛠️ Middleware Components

### **Authentication & Authorization**
- **authMiddleware.js**: JWT token validation, role-based access control
- **Functions**: `protect`, `admin`

### **File Upload**
- **uploadMiddleware.js**: Multer configuration for image uploads
- **Features**: File validation, size limits, unique naming

### **Validation**
- **validateMiddleware.js**: Request validation using express-validator
- **Error Handling**: Comprehensive error responses

### **Error Management**
- **errorMiddleware.js**: Centralized error handling
- **Functions**: `notFound`, `errorHandler`

---

## 📊 Database Schema Overview

### **Admin Collection**
```javascript
{
  name: String (required),
  email: String (required, unique),
  password: String (required, hashed),
  role: String (enum: ['admin', 'manager'], default: 'admin'),
  timestamps: true
}
```

### **Ticket Collection**
```javascript
{
  ticketNumber: String (required, unique, indexed),
  customerName: String (required),
  mobileNumber: String (required),
  email: String (required, lowercase),
  serviceType: String (enum: ['CCTV', 'IT', 'Printer', 'AMC', 'Other']),
  problemDescription: String (required),
  address: String (required),
  status: String (enum: ['Open', 'In Progress', 'Closed'], default: 'Open'),
  assignedTechnician: String (default: ''),
  notes: [{ message: String, addedBy: String, createdAt: Date }],
  timestamps: true
}
```

### **Banner Collection**
```javascript
{
  title: String (required, maxlength: 200),
  description: String (required, maxlength: 1000),
  image: String (required),
  status: String (enum: ['active', 'inactive'], default: 'active'),
  position: String (enum: ['home', 'about', 'services', 'contact'], default: 'home'),
  timestamps: true
}
```

---

## 🚀 API Endpoints Documentation

### **Authentication Routes**
```
POST /api/admin/login
Body: { email, password }
Response: { token, admin: { id, name, email, role } }
```

### **Admin Dashboard**
```
GET /api/admin/dashboard/stats (protected)
GET /api/admin/tickets (protected)
GET /api/admin/tickets/:id (protected)
PUT /api/admin/tickets/:id (protected)
```

### **Customer Operations**
```
POST /api/customer/tickets
Body: { fullName, mobileNumber, email, serviceType, problemDescription, address }

POST /api/customer/tickets/status
Body: { ticketNumber, contact }

POST /api/customer/contact
Body: { name, email, mobile, message }
```

### **Banner Management**
```
POST /api/banners (admin only, multipart/form-data)
Body: { title, description, status, position, image: file }

GET /api/banners?page=1&limit=10&status=active&position=home
GET /api/banners/active?position=home
GET /api/banners/:id
PUT /api/banners/:id (admin only, multipart/form-data)
DELETE /api/banners/:id (admin only)
```

---

## 🔧 Utilities & Services

### **Core Utilities**
- **generateToken.js**: JWT token generation
- **generateTicketNumber.js**: Unique ticket number generation
- **emailService.js**: Email notifications (nodemailer)

### **Features**
- JWT-based authentication
- Role-based access control
- File upload with validation
- Input sanitization & validation
- Pagination support
- Error handling & logging
- CORS configuration
- Rate limiting
- Security headers (helmet)

---

## 📁 Project Structure

```
backend/
├── src/
│   ├── models/           # Database models
│   ├── controllers/      # Business logic
│   ├── routes/          # API routes
│   ├── middleware/      # Custom middleware
│   ├── utils/           # Helper functions
│   ├── config/          # Configuration files
│   ├── seeders/         # Database seeders
│   ├── app.js           # Express app configuration
│   └── server.js        # Server entry point
├── uploads/
│   └── banners/         # Banner images
├── .env                 # Environment variables
├── .env.example         # Environment template
├── package.json         # Dependencies
└── README.md           # Project documentation
```

---

## 🚀 Getting Started

### **Environment Setup**
1. Install dependencies: `npm install`
2. Create `.env` file from `.env.example`
3. Configure MongoDB connection
4. Set JWT secret and email credentials

### **Database Seeding**
```bash
npm run seed:admin  # Create admin user
```

### **Development Server**
```bash
npm run dev          # Development with nodemon
npm start           # Production server
```

---

## 🔐 Security Features

- JWT token authentication
- Password hashing with bcryptjs
- Rate limiting (200 requests/15min)
- CORS configuration
- Helmet security headers
- Input validation & sanitization
- File upload restrictions
- Admin-only route protection

---

## 📈 Performance Considerations

- Database indexing on frequently queried fields
- Pagination for large datasets
- File size limits (5MB for uploads)
- Efficient error handling
- Memory-optimized middleware chain
- Static file serving optimization

---

## 🎯 Business Logic Flow

### **Ticket Management Flow**
1. Customer submits ticket → Auto-generates ticket number
2. Admin views dashboard → Sees statistics & recent tickets
3. Admin updates ticket status → Changes assigned technician & adds notes
4. Customer checks status → Uses ticket number + contact info

### **Banner Management Flow**
1. Admin creates banner → Uploads image with title/description
2. Banner stored with position & status → Organized by page placement
3. Public API serves active banners → Filtered by position
4. Admin manages banners → CRUD operations with authentication

---

## 📝 Development Notes

- **ES6 Modules**: Using `import/export` syntax
- **Async/Await**: Modern asynchronous programming
- **RESTful Design**: Standard HTTP methods & status codes
- **Error First**: Comprehensive error handling
- **Scalable**: Modular architecture for easy extension
- **Testable**: Separated concerns for unit testing

---

*Last Updated: March 30, 2026*  
*Version: 1.0.0*
