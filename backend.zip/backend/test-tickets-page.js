import axios from 'axios';

// Mock localStorage
global.localStorage = {
  data: {},
  getItem: function(key) {
    return this.data[key] || null;
  },
  setItem: function(key, value) {
    this.data[key] = value;
  }
};

// API setup
const api = axios.create({
  baseURL: 'http://localhost:3000/api',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
});

api.interceptors.request.use((config) => {
  const adminAuth = global.localStorage.getItem('adminAuth');
  const parsed = adminAuth ? JSON.parse(adminAuth) : null;
  const token = parsed?.data?.token || parsed?.token;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

async function testTicketsPage() {
  console.log('🎫 TESTING TICKETS PAGE SPECIFICALLY');
  console.log('='.repeat(50));
  
  try {
    // Login
    console.log('\n1. 🔐 Logging in...');
    const login = await api.post('/admin/login', {
      email: 'admin@example.com',
      password: 'Admin@123'
    });
    global.localStorage.setItem('adminAuth', JSON.stringify(login.data));
    console.log('✅ Login successful');
    
    // Get tickets like TicketsPage does
    console.log('\n2. 🎫 Getting tickets (TicketsPage method)...');
    const { data } = await api.get('/admin/tickets');
    console.log('API Response structure:', {
      success: data.success,
      count: data.count,
      dataType: Array.isArray(data.data) ? 'Array' : 'Not Array',
      dataLength: data.data?.length || 0
    });
    
    // Simulate TicketsPage data extraction
    console.log('\n3. 📱 Simulating TicketsPage.jsx...');
    const tickets = data.data; // This is what TicketsPage uses
    
    console.log('Tickets array:', {
      isArray: Array.isArray(tickets),
      length: tickets.length,
      firstTicket: tickets[0] ? {
        _id: tickets[0]._id,
        ticketNumber: tickets[0].ticketNumber,
        customerName: tickets[0].customerName,
        serviceType: tickets[0].serviceType,
        status: tickets[0].status,
        createdAt: tickets[0].createdAt
      } : 'No tickets'
    });
    
    // Test mapping (this is where the issue was)
    console.log('\n4. 🗺️  Testing ticket mapping...');
    if (Array.isArray(tickets)) {
      console.log('✅ Tickets is array, mapping should work');
      
      // Test the key field
      const firstTicket = tickets[0];
      console.log('Key field test:');
      console.log('  ticket._id:', firstTicket._id); // ✅ This is correct
      console.log('  ticket.id:', firstTicket.id); // ❌ This doesn't exist
      
      // Test status badge
      const statusColors = {
        'Open': 'bg-warning',
        'In Progress': 'bg-info',
        'Closed': 'bg-success'
      };
      const statusBadge = statusColors[firstTicket.status] || 'bg-secondary';
      console.log('Status badge for', firstTicket.status + ':', statusBadge);
      
    } else {
      console.log('❌ Tickets is not an array!');
    }
    
    console.log('\n5. 🎯 ISSUES FOUND & FIXED:');
    console.log('✅ Fixed: ticket.id → ticket._id');
    console.log('✅ Fixed: Added admin-tickets-page CSS class');
    console.log('✅ Data extraction: data.data (correct)');
    
    console.log('\n🎉 TICKETS PAGE SHOULD NOW WORK!');
    console.log('   • Ab tickets show honge');
    console.log('   • Table render hoga');
    console.log('   • Status badges kaam karenge');
    
  } catch (error) {
    console.error('❌ Test failed:', error.response?.data || error.message);
  }
}

testTicketsPage();
